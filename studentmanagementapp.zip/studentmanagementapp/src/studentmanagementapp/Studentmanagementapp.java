/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package studentmanagementapp;

import java.util.Scanner;

/**
 *
 * @author lebom
 */
public class Studentmanagementapp {

    
    public static void main(String[] args) {
   
        Scanner scanner = new Scanner(System.in);
        int choice;
        do {
            System.out.println("*******************************");
            System.out.println("STUDENT MANAGEMENT APPLICATION");
            System.out.println("*******************************");
            System.out.println("Enter (1) to launch menu or any other key to exit");
            choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            if (choice == 1) {
                launchMenu(scanner);
            }
        } while (choice == 1);
    }

    private static void launchMenu(Scanner scanner) {
        int option;
        do {
            System.out.println("Please select one of the following menu items:");
            System.out.println("(1) Capture a new student.");
            System.out.println("(2) Search for a student.");
            System.out.println("(3) Delete a student.");
            System.out.println("(4) Print student report.");
            System.out.println("(5) Exit Application.");

            option = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (option) {
                case 1:
                    captureNewStudent(scanner);
                    break;
                case 2:
                    searchStudent(scanner);
                    break;
                case 3:
                    deleteStudent(scanner);
                    break;
                case 4:
                    Student.displayAllStudents();
                    break;
                case 5:
                    System.out.println("Exiting application...");
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        } while (option != 5);
    }

    private static void captureNewStudent(Scanner scanner) {
        System.out.println("CAPTURE A NEW STUDENT");
        System.out.println("*******************************");

        System.out.print("Enter the student id: ");
        String id = scanner.nextLine();

        System.out.print("Enter the student name: ");
        String name = scanner.nextLine();

        int age;
        while (true) {
            System.out.print("Enter the student age: ");
            if (scanner.hasNextInt()) {
                age = scanner.nextInt();
                scanner.nextLine();  // Consume newline
                if (age >= 16) break;
                else System.out.println("You have entered an incorrect student age! Please re-enter the student age >= 16.");
            } else {
                System.out.println("You have entered an incorrect student age character! Please re-enter the student age >>");
                scanner.next();  // Consume invalid input
            }
        }

        System.out.print("Enter the student email: ");
        String email = scanner.nextLine();

        System.out.print("Enter the student course: ");
        String course = scanner.nextLine();

        Student newStudent = new Student(id, name, age, email, course);
        Student.saveStudent(newStudent);
    }

    private static void searchStudent(Scanner scanner) {
        System.out.print("Enter the student id to search: ");
        String id = scanner.nextLine();

        Student student = Student.searchStudent(id);
        if (student != null) {
            student.displayStudent();
        } else {
            System.out.println("Student with ID: " + id + " was not found.");
        }
    }

    private static void deleteStudent(Scanner scanner) {
        System.out.print("Enter the student id to delete: ");
        String id = scanner.nextLine();

        System.out.print("Are you sure you want to delete student " + id + " from the system? (Yes/No): ");
        String confirmation = scanner.nextLine();

        if (confirmation.equalsIgnoreCase("Yes")) {
            if (!Student.deleteStudent(id)) {
                System.out.println("Student with ID: " + id + " was not found.");
            }
        } else {
            System.out.println("Deletion cancelled.");
        }
    }
}

    
    


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package studentmanagementapp;
import java.util.ArrayList;


/**
 *
 * @author lebom
 */
class Student {
    
    private String studentId;
    private String name;
    private int age;
    private String email;
    private String course;

    // Constructor
    public Student(String studentId, String name, int age, String email, String course) {
        this.studentId = studentId;
        this.name = name;
        this.age = age;
        this.email = email;
        this.course = course;
    }

    // Getters
    public String getStudentId() {
        return studentId;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getEmail() {
        return email;
    }

    public String getCourse() {
        return course;
    }

    // Display student details
    public void displayStudent() {
        System.out.println("STUDENT ID: " + studentId);
        System.out.println("STUDENT NAME: " + name);
        System.out.println("STUDENT AGE: " + age);
        System.out.println("STUDENT EMAIL: " + email);
        System.out.println("STUDENT COURSE: " + course);
    }

    // Static list to store students
    private static ArrayList<Student> students = new ArrayList<>();

    // Save student
    public static void saveStudent(Student student) {
        students.add(student);
        System.out.println("Student with ID: " + student.getStudentId() + " has been saved.");
    }

    // Search student by ID
    public static Student searchStudent(String id) {
        for (Student student : students) {
            if (student.getStudentId().equals(id)) {
                return student;
            }
        }
        return null;
    }

    // Delete student by ID
    public static boolean deleteStudent(String id) {
        Student student = searchStudent(id);
        if (student != null) {
            students.remove(student);
            System.out.println("Student with ID: " + id + " has been deleted.");
            return true;
        }
        return false;
    }

    // Display all students
    public static void displayAllStudents() {
        if (students.isEmpty()) {
            System.out.println("No students found.");
        } else {
            for (int i = 0; i < students.size(); i++) {
                System.out.println("STUDENT " + (i + 1));
                students.get(i).displayStudent();
                System.out.println("-------------------------------");
            }
        }
    }
}

//code attribution 
//this code has been inspired by stack overflow 
//https://stackoverflow.com/questions/157944/create-arraylist-from-array?rq=1


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inventorymanagementsystem;

/**
 *
 * @author lebom
 */
public class Product extends Item {
  
   
    public Product(int id, String name, int quantity, double price) {
        super(id, name, quantity, price);
    }
}



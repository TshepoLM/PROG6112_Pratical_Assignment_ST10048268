/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inventorymanagementsystem;
import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author lebom
 */
public class Inventory {

    private final ArrayList<Product> products = new ArrayList<>();
    private final Scanner scanner = new Scanner(System.in);

    public void addProduct() {
        System.out.print("Enter Product ID: ");
        int id = scanner.nextInt();
        scanner.nextLine(); 
        System.out.print("Enter Product Name: ");
        String name = scanner.nextLine();
        System.out.print("Enter Quantity: ");
        int quantity = scanner.nextInt();
        System.out.print("Enter Price: ");
        double price = scanner.nextDouble();

        Product product = new Product(id, name, quantity, price);
        products.add(product);
        System.out.println("Product added successfully!");
    }

    public void updateProduct() {
        System.out.print("Enter Product ID to update: ");
        int id = scanner.nextInt();
        Product product = findProductById(id);
        if (product != null) {
            System.out.print("Enter new Product Name: ");
            scanner.nextLine(); 
            product.setName(scanner.nextLine());
            System.out.print("Enter new Quantity: ");
            product.setQuantity(scanner.nextInt());
            System.out.print("Enter new Price: ");
            product.setPrice(scanner.nextDouble());
            System.out.println("Product updated successfully!");
        } else {
            System.out.println("Product not found!");
        }
    }

    public void deleteProduct() {
        System.out.print("Enter Product ID to delete: ");
        int id = scanner.nextInt();
        Product product = findProductById(id);
        if (product != null) {
            products.remove(product);
            System.out.println("Product deleted successfully!");
        } else {
            System.out.println("Product not found!");
        }
    }

    public void displayInventory() {
        if (products.isEmpty()) {
            System.out.println("No products in inventory.");
        } else {
            for (Product product : products) {
                System.out.println(product);
            }
        }
    }

    private Product findProductById(int id) {
        for (Product product : products) {
            if (product.getId() == id) {
                return product;
            }
        }
        return null;
    }
}

//code attribution
//this code was sourced from stack overflow 
//https://stackoverflow.com/questions/157944/create-arraylist-from-array?rq=1
//code attibution
//this code was inspired by youtube
//https://www.youtube.com/watch?v=uHCR9btEIyA&list=PLRmvSuBP-XfypvxMMCEx7reSl7PhdZ82_&index=2

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package inventorymanagementsystem;
import java.util.Scanner;
/**
 *
 * @author lebom
 */
public class InventoryManagementSystem {

    
    public static void main(String[] args) {
      
        Inventory inventory = new Inventory();
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\nInventory Management System");
            System.out.println("1. Add Product");
            System.out.println("2. Update Product");
            System.out.println("3. Delete Product");
            System.out.println("4. Display Inventory");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    inventory.addProduct();
                    break;
                case 2:
                    inventory.updateProduct();
                    break;
                case 3:
                    inventory.deleteProduct();
                    break;
                case 4:
                    inventory.displayInventory();
                    break;
                case 5:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 5);

        scanner.close();
    }
}
 //code attribution 
//this code was sourced from stack overflow 
//https://stackoverflow.com/questions/18395615/joptionpane-with-username-and-password-input
    
    


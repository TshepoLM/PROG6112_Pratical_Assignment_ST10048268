/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package inventorymanagementsystem;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author lebom
 */
public class InventoryTest {
    
    public InventoryTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    
    @Test
    public void testAddProduct() {
        System.out.println("addProduct");
        Inventory instance = new Inventory();
        instance.addProduct();
        
    }

   
    @Test
    public void testUpdateProduct() {
        System.out.println("updateProduct");
        Inventory instance = new Inventory();
        instance.updateProduct();
        
    }

    
    @Test
    public void testDeleteProduct() {
        System.out.println("deleteProduct");
        Inventory instance = new Inventory();
        instance.deleteProduct();
        
    }

    
    @Test
    public void testDisplayInventory() {
        System.out.println("displayInventory");
        Inventory instance = new Inventory();
        instance.displayInventory();
       
    }
    
}

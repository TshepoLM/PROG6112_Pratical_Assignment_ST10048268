/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package inventorymanagementsystem;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author lebom
 */
public class ItemTest {
    
    public ItemTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    
    @Test
    public void testGetId() {
        System.out.println("getId");
        Item instance = null;
        int expResult = 0;
        int result = instance.getId();
        assertEquals(expResult, result);
        
    }

    
    @Test
    public void testGetName() {
        System.out.println("getName");
        Item instance = null;
        String expResult = "";
        String result = instance.getName();
        assertEquals(expResult, result);
        
    }

   
    @Test
    public void testSetName() {
        System.out.println("setName");
        String name = "";
        Item instance = null;
        instance.setName(name);
        
    }

    
    @Test
    public void testGetQuantity() {
        System.out.println("getQuantity");
        Item instance = null;
        int expResult = 0;
        int result = instance.getQuantity();
        assertEquals(expResult, result);
        
    }

  
    @Test
    public void testSetQuantity() {
        System.out.println("setQuantity");
        int quantity = 0;
        Item instance = null;
        instance.setQuantity(quantity);
       
    }

   
    @Test
    public void testGetPrice() {
        System.out.println("getPrice");
        Item instance = null;
        double expResult = 0.0;
        double result = instance.getPrice();
        assertEquals(expResult, result, 0);
      
    }

   
    @Test
    public void testSetPrice() {
        System.out.println("setPrice");
        double price = 0.0;
        Item instance = null;
        instance.setPrice(price);
        
    }

   
    @Test
    public void testToString() {
        System.out.println("toString");
        Item instance = null;
        String expResult = "";
        String result = instance.toString();
        assertEquals(expResult, result);
        
    }
    
}
